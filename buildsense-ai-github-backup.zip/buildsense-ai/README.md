# BuildSense AI — Multimodal Construction Intelligence Platform

**BuildSense AI** is a production-grade, multimodal construction technology web platform built for general contractors, site engineers, project managers, and safety auditors. It merges computer vision safety audits, forensic crack observations, Critical Path Method (CPM) project scheduling, replacement-cost property valuation, and real-time weather-aware operational advisories into a single industrial SaaS interface.

---

## Architecture & Technology Stack

- **Frontend**: React 19, Vite, Tailwind CSS (Industrial Navy theme: `#0B1020`, `#111827`, `#172033` with `#FF8A00` Orange & `#22D3EE` Cyan accents), React Router, Lucide React icons, Recharts, Axios.
- **Backend**: Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy 2.0, Uvicorn, Python-Multipart, PyJWT, Bcrypt.
- **Database**: SQLite for local rapid development (`buildsense.db`), fully compatible with PostgreSQL for production.
- **AI Intelligence**: Configurable Multimodal Large Language Model integration (Google Gemini 1.5 Flash / OpenAI) with realistic, structured, clearly labeled demo mode when credentials are not configured.
- **Quality Assurance**: Automated test suite with Pytest testing 13 distinct workflow suites.

---

## 1. Prerequisites

Before installing the application, ensure your system has the following tools installed:
- **Node.js**: v18.0.0 or later (v24+ recommended)
- **npm**: v9.0.0 or later
- **Python**: v3.11 or later
- **Git**

---

## 2. Project Installation & Setup

Clone or navigate to the repository directory:

```powershell
cd "c:\Users\jai ram\Documents\buildsense-ai"
```

The repository structure is organized as:

```
buildsense-ai/
    frontend/         # React + Vite + Tailwind application
    backend/          # FastAPI backend, SQLite database & tests
    docs/             # Architectural & test documentation
    README.md
    .gitignore
```

---

## 3. Backend Setup & Virtual Environment

From the project root, open a Windows PowerShell terminal:

```powershell
cd backend

# Create Python virtual environment
python -m venv .venv

# Activate the virtual environment
.venv\Scripts\Activate.ps1

# Install backend dependencies
pip install -r requirements.txt
```

---

## 4. Frontend Dependency Installation

In a separate terminal, install the frontend packages:

```powershell
cd frontend
npm install
```

---

## 5. Environment Variable Configuration

### Backend Configuration (`backend/.env`)

Copy the example file or create `backend/.env`:

```powershell
cd backend
Copy-Item .env.example .env
```

Default contents of `backend/.env`:

```ini
PROJECT_NAME="BuildSense AI — Construction Intelligence Platform"
VERSION="1.0.0"
DATABASE_URL="sqlite:///./buildsense.db"
SECRET_KEY="buildsense-local-dev-secret-key-2026"
ALGORITHM="HS256"
ACCESS_TOKEN_EXPIRE_MINUTES=1440

# AI Provider Credentials (Leave blank to use structured Demo Mode)
GEMINI_API_KEY=""
OPENAI_API_KEY=""

# Weather Provider Credentials (Leave blank for Demo Telemetry)
WEATHER_API_KEY=""

MAX_FILE_SIZE_MB=15
ENABLE_DEMO_MODE=true
```

### Frontend Configuration (`frontend/.env`)

```ini
VITE_API_URL=/api
```

---

## 6. Database Initialization & Seeding

The SQLite database (`buildsense.db`) is automatically initialized and seeded with realistic demo data on the first startup of the backend server. The initial seed includes:
- 4 Demo Persona Users (`Administrator`, `Project Manager`, `Site Engineer`, `Safety Officer`)
- 4 Realistic Projects (`Hudson Commercial Tower`, `Bayside Logistics Hub`, `Greenwood Eco-Park`, `Metro Rail Station 4`)
- Associated Tasks, Milestones, Safety Inspections, Crack Logs, and Daily Reports.

To migrate to **PostgreSQL** in production:
1. Update `DATABASE_URL` in `backend/.env`:
   ```
   DATABASE_URL="postgresql://user:password@localhost:5432/buildsense_db"
   ```
2. Install `psycopg2-binary`:
   ```powershell
   pip install psycopg2-binary
   ```
3. Run the backend — SQLAlchemy will create all tables automatically.

---

## 7. Running the Application

### Start the FastAPI Backend

In your backend terminal (with `.venv` active):

```powershell
cd backend
.venv\Scripts\Activate.ps1
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

- Backend API: `http://127.0.0.1:8000`
- Interactive Swagger UI: `http://127.0.0.1:8000/docs`
- Redoc Documentation: `http://127.0.0.1:8000/redoc`

### Start the React Frontend

In your frontend terminal:

```powershell
cd frontend
npm run dev
```

- Frontend Application: `http://localhost:5173` (or `http://127.0.0.1:5173`)

---

## 8. Demo User Personas (1-Click Instant Login)

On the login page (`/login`), click any of the 1-click demo personas to instantly access the platform with role-tailored permissions:

| Persona | Name | Role | Email |
| :--- | :--- | :--- | :--- |
| **Director / VP** | Marcus Vance | Administrator | `admin@buildsense.ai` |
| **Project Manager** | Sarah Jenkins, PMP | Project Manager | `pm@buildsense.ai` |
| **Site Engineer** | David Chen, PE | Site Engineer | `engineer@buildsense.ai` |
| **Safety Officer** | Elena Rodriguez, CSP | Safety Officer | `safety@buildsense.ai` |

*Default password for manual login: `BuildSense2026!`*

---

## 9. Multimodal AI & Weather Configuration

### Configuring Google Gemini Multimodal AI
To enable live image analysis for safety audits, crack detection, and assistant chat:
1. Obtain an API key from [Google AI Studio](https://aistudio.google.com/).
2. In `backend/.env`, set:
   ```ini
   GEMINI_API_KEY="your-gemini-api-key-here"
   ```
3. Restart the backend. The platform will automatically detect the key and switch from `"mode": "demo"` to `"mode": "ai"`.

### Configuring Live Weather Telemetry
1. Obtain an API key from [OpenWeatherMap](https://openweathermap.org/api).
2. In `backend/.env`, set:
   ```ini
   WEATHER_API_KEY="your-openweathermap-key-here"
   ```

*When external API keys are omitted, BuildSense AI operates in an explicitly labeled Demo Simulation Mode. It never pretends that an external API call succeeded when it did not.*

---

## 10. Automated Testing

Run the automated backend test suite with Pytest:

```powershell
cd backend
.venv\Scripts\Activate.ps1
pytest -v
```

All 13 tests execute against an isolated test SQLite database and verify:
- Health checks & provider diagnostics
- User registration, password hashing, and authentication
- Project CRUD & task tracking
- Multimodal safety analysis & schema validation
- Structural crack detection & calibrated measurement disclaimers
- Parametric property valuation
- AI project planning & WBS synthesis
- Weather advisory calculation & crane cutoff thresholds
- AI Assistant chat
- Daily site superintendent logs
- Dashboard analytics aggregation
- Unauthorized route protection

---

## 11. Production Build & Deployment

### Build Frontend for Production

```powershell
cd frontend
npm run build
```

This generates an optimized static build in `frontend/dist/`.

### Serving Frontend via Nginx or Cloudflare
Point your web server to `frontend/dist/index.html` with fallback routing for single-page applications (SPA).

---

## 12. Troubleshooting Common Issues

1. **Python Execution Policy on Windows**:
   If PowerShell blocks activating virtual environments, run:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
2. **Port 8000 Already in Use**:
   Run uvicorn on another port, e.g. `--port 8001`, and update Vite's `proxy` in `frontend/vite.config.js`.
3. **Image Upload Restrictions**:
   Supported image types: `image/jpeg`, `image/png`, `image/webp`. Maximum file size: `15MB`.

---

## 13. Safety & Forensic Engineering Disclaimers

> [!IMPORTANT]
> **Safety Screening Notice**: Automated AI visual hazard detection is intended for preliminary screening only and does not replace certified OSHA/NEBOSH physical site inspections. Human review is required before closing critical safety observations.
>
> **Forensic Structural Notice**: Single-perspective ordinary photographs cannot establish calibrated crack width, subsurface reinforcement integrity, or remaining building lifespan. Critical shear fractures or foundation settlement must be evaluated on-site by a licensed Professional Structural Engineer (PE / SE).
